﻿using System;
/** 
 * Name: Tao Ji Yang
 * Courses: NMAD.180:PROGRAMMING FUNDAMENTALS I:MOBILE DOMAIN
 * Due Date; 2/26/2021
 * Purpose: MCE 08
 * Caveats: Connecting Array with If statement was little werid because I couldn't use string, I tried to use with Switch but I kept messing it up. I just ran out of time but I will practice this again with Switch. 
 */
namespace Arrays
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            const double SALES_TAX = .08;

            double[] Price = new double[4];
            string[] NameoftheItem = new string[4];

            NameoftheItem[0] = "Ski Jacket";
            NameoftheItem[1] = "Ski Pants";
            NameoftheItem[2] = "Cargo Shorts";
            NameoftheItem[3] = "Printed T-Shirt";

            Price[0] = 129.50;
            Price[1] = 85.90;
            Price[2] = 57.95;
            Price[3] = 30.75;

            Console.WriteLine("*** Lands Beginning ***");
            Console.WriteLine();
            Console.WriteLine("     Item        Price");
            Console.WriteLine($"1.{NameoftheItem[0]} |      {Price[0]:C}");
            Console.WriteLine($"2.{NameoftheItem[1]} |      {Price[1]:C}");
            Console.WriteLine($"3.{NameoftheItem[2]} |      {Price[2]:C}");
            Console.WriteLine($"4.{NameoftheItem[3]} |      {Price[3]:C}");

            int selectionofItem;
            Console.Write("Select an item to purchase: ");
            if (int.TryParse(Console.ReadLine(), out selectionofItem))
            {
                int NumberofTotalOfItem;
                double Cost;
                double Tax;
                double Total;
                Console.Write("\nHow many do you want to purchase: ");
                if (int.TryParse(Console.ReadLine(), out NumberofTotalOfItem))
                {
                    Cost = Price[selectionofItem - 1] * NumberofTotalOfItem;
                    Tax = Cost * SALES_TAX;
                    Total = Cost + Tax;
                    Console.WriteLine("\n--- Printed T-Shirt ---");
                    Console.WriteLine($"Quantity: {NumberofTotalOfItem}");
                    Console.WriteLine($"Cost: {Cost:C}");
                    Console.WriteLine($"Tax: {Tax:C}");
                    Console.WriteLine($"Total: {Total:C}");
                }
                else
                {
                    Console.WriteLine("Invalid Input, please try again.");
                    Environment.Exit(0);
                }
            }
            else
            {
                Console.WriteLine("Invalid Input, please try again.");
                Environment.Exit(0);
            }
        }
    }
}
